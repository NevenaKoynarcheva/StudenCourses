import model.Student;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import java.sql.*;
import java.util.ArrayList;

import java.util.List;

public class Main {
    private static final String url = "jdbc:postgresql://localhost:5432/courses";
    private static final String username = "postgres";
    private static final String password = "1234";

    public static void main(String[] args) {
        String sql = "SELECT s.first_name, s.last_name, c.course_name, c.course_time, c.course_credit, c.instructor " +
                "FROM students s " +
                "JOIN student_courses e ON s.student_id = e.student_id " +
                "JOIN courses c ON e.course_id = c.course_id " +
                "WHERE e.completion_date = true " +
                "GROUP BY s.student_id, s.first_name, s.last_name " +
                "HAVING SUM(c.course_credit) > 50";

        try {
            Class.forName("org.postgresql.Driver");
            try (Connection connection = DriverManager.getConnection(url, username, password);
                 PreparedStatement statement = connection.prepareStatement(sql)) {

                try (ResultSet resultSet = statement.executeQuery()) {
                    List<Student> students = new ArrayList<>();

                    while (resultSet.next()) {
                        String firstName = resultSet.getString("first_name");
                        String lastName = resultSet.getString("last_name");
                        String courseName = resultSet.getString("course_name");
                        int courseTime = resultSet.getInt("course_time");
                        int courseCredit = resultSet.getInt("course_credit");
                        String instructor = resultSet.getString("instructor");

                        students.add(new Student(firstName, lastName, courseName, courseCredit, courseTime, instructor));
                    }

                    writeReport(students);
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public static void writeReport(List<Student> students) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("csv/report.csv"))) {
            for (Student student : students) {
                writer.write(student.getFirstName() + ", " + student.getLastName() + ", " +
                        student.getCourseName() + ", " + student.getCredit() + ", " +
                        student.getTime() +  ", " + student.getInstructor() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
